-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2017 at 11:14 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `b_admin`
--

CREATE TABLE IF NOT EXISTS `b_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `b_admin`
--

INSERT INTO `b_admin` (`admin_id`, `email`, `pwd`) VALUES
(1, 'surajkumar9218@gmail.com', 'aa56cf4d7cfc0c0a3114a0ac6a9e32cb');

-- --------------------------------------------------------

--
-- Table structure for table `b_categories`
--

CREATE TABLE IF NOT EXISTS `b_categories` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `full_desc` text NOT NULL,
  `add_time` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `b_categories`
--

INSERT INTO `b_categories` (`cat_id`, `parent_id`, `title`, `img`, `slug`, `full_desc`, `add_time`, `update_time`) VALUES
(6, 0, 'Core php', 'icon_php.png', 'core-php', '<p>This is Corephp Category.</p>', '1510478048', '2017-11-12 09:14:08'),
(7, 0, 'Codeigniter', '652438_9fee_2.jpg', 'codeigniter', '<p>This is codeigniter category</p>', '1510478094', '2017-11-12 09:14:54'),
(8, 0, 'Html', '14570828119302_illu-cours_html5-css3.png', 'html', '<p>This is HTML category.</p>', '1510478120', '2017-11-12 09:15:20'),
(9, 0, 'Wordpress', 'WordPress_logo4.jpg', 'wordpress', '<p>This is Wordpress Category.</p>', '1510478144', '2017-11-12 09:15:44'),
(10, 0, 'Javascript', '495484_385c_3.jpg', 'javascript', '<p>Javascript Category</p>', '1510478193', '2017-11-12 09:16:33');

-- --------------------------------------------------------

--
-- Table structure for table `b_comments`
--

CREATE TABLE IF NOT EXISTS `b_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `b_comments`
--

INSERT INTO `b_comments` (`comment_id`, `post_id`, `name`, `email`, `message`, `add_time`) VALUES
(4, 13, 'Suraj', 'surajkumar9218@gmail.com', 'This is Demo Comment.', '2017-11-12 10:04:03');

-- --------------------------------------------------------

--
-- Table structure for table `b_pages`
--

CREATE TABLE IF NOT EXISTS `b_pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `full_desc` text NOT NULL,
  `add_time` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `b_pages`
--

INSERT INTO `b_pages` (`page_id`, `title`, `slug`, `full_desc`, `add_time`, `update_time`) VALUES
(4, 'About Us', 'about-us', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. <br /><br />Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. <br /><br />It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '1510478621', '2017-11-12 09:23:41'),
(5, 'Contact Us', 'contact-us', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. <br /><br />Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. <br /><br />It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '1510478652', '2017-11-12 09:24:12');

-- --------------------------------------------------------

--
-- Table structure for table `b_posts`
--

CREATE TABLE IF NOT EXISTS `b_posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `full_desc` text NOT NULL,
  `views` varchar(255) NOT NULL DEFAULT '0',
  `add_time` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `b_posts`
--

INSERT INTO `b_posts` (`post_id`, `cat_id`, `title`, `img`, `slug`, `full_desc`, `views`, `add_time`, `update_time`) VALUES
(4, '6', 'Post 1', '1.jpg', 'post-1', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.<br /><br /></p>', '3', '1510478401', '2017-11-12 10:13:25'),
(5, '7', 'Post 2', '22.jpg', 'post-2', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>', '0', '1510478558', '2017-11-12 09:36:32'),
(6, '6', 'Post 3', '39.jpg', 'post-3', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.<br /><br /></p>', '0', '1510479176', '2017-11-12 09:37:05'),
(7, '6,7,9', 'Post 4', '41.jpg', 'post-4', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>', '0', '1510479207', '2017-11-12 09:35:34'),
(8, '7,9', 'Post 5', '51.jpg', 'post-5', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>', '0', '1510479219', '2017-11-12 09:35:44'),
(9, '7,8', 'Post 6', '63.jpg', 'post-6', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>', '0', '1510479477', '2017-11-12 09:37:57'),
(10, '8,9,10', 'Post 7', '7.jpg', 'post-7', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>', '0', '1510479489', '2017-11-12 09:38:09'),
(11, '7,8,9,10', 'Post 8', '81.jpg', 'post-8', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>', '0', '1510479503', '2017-11-12 09:38:23'),
(12, '6', 'Post 9', '9.jpg', 'post-9', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>', '0', '1510479513', '2017-11-12 09:38:33'),
(13, '6', 'Post 10', '800px_COLOURBOX1167880.jpg', 'post-10', '<p>Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>', '3', '1510479569', '2017-11-12 10:04:03');

-- --------------------------------------------------------

--
-- Table structure for table `captcha`
--

CREATE TABLE IF NOT EXISTS `captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,
  `captcha_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `word` varchar(20) NOT NULL,
  PRIMARY KEY (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=94 ;

--
-- Dumping data for table `captcha`
--

INSERT INTO `captcha` (`captcha_id`, `captcha_time`, `ip_address`, `word`) VALUES
(82, 1510474408, '::1', '423154'),
(83, 1510474414, '::1', '77916'),
(84, 1510474442, '::1', '732227'),
(85, 1510474446, '::1', '14047'),
(86, 1510474461, '::1', '483941'),
(87, 1510474463, '::1', '825613'),
(88, 1510480296, '::1', '970150'),
(89, 1510480655, '::1', '712589'),
(90, 1510480897, '::1', '60574'),
(91, 1510481025, '::1', '966615'),
(92, 1510481044, '::1', '442429'),
(93, 1510481605, '::1', '680563');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
